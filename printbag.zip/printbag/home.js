function myFunction() {
  console.log("working");
  var click = document.getElementById("mySidepanel");

  click.style.width = "95%";


}

function closeNav() {
  document.getElementById("mySidepanel").style.width = "0";
}


function popup() {
  console.log("popup");

  var dum = document.getElementById("myPopup");
  var close = document.getElementById('close');
  if (dum.style.display == 'block') {
    dum.style.display = 'none';
    close.style.display = 'none';
  } else {
    dum.style.display = 'block';
    close.style.display = 'block';


  }




}

function close() {
  console.log("closing");
  document.getElementById('close').style.display = 'none';

}



// search block
function openSearch() {
  document.getElementById("myOverlay").style.display = "block";
}

function closeSearch() {
  document.getElementById("myOverlay").style.display = "none";
}

//mobile dropdown
function mobiledropdown() {
  var mobiledropdown = document.getElementById("mobile-dropdown");
  if (mobiledropdown.style.display == 'block') {
    mobiledropdown.style.display = 'none';
  } else {
    mobiledropdown.style.display = 'block';


  }

}


//geting id for mobile submenu 
function reply_click(clicked_id) {

  var id = document.getElementById(clicked_id).nextSibling.nextElementSibling;
  if (id.style.display == 'block') {
    id.style.display = 'none';
  } else {
    id.style.display = 'block';


  }
    
}